<?php 

if( ! function_exists( 'road_get_slider_setting' ) ) {
	function road_get_slider_setting() {
		return array(
			array(
				'type'        => 'dropdown',
				'holder'      => 'div',
				'heading'     => esc_html__( 'Style', 'ginza' ),
				'param_name'  => 'style',
				'value'       => array(
					__( 'Grid view (default)', 'ginza' )                    => 'product-grid',
					__( 'Grid view 2 (product bg 2 (see Demo 2))', 'ginza' )   => 'product-grid-2',
					__( 'List view 1', 'ginza' )                  => 'product-list',
					__( 'List view 2', 'ginza' )                  => 'product-list-2',
					__( 'Grid view with countdown', 'ginza' )     => 'product-grid-countdown',
				),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Enable slider', 'ginza' ),
				'description' => __( 'If slider is enabled, the "column" ins General group is the number of rows ', 'ginza' ),
				'param_name'  => 'enable_slider',
				'value'       => true,
				'save_always' => true, 
				'group'       => __( 'Slider Options', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'heading'    => __( 'Number of columns (screen: over 1500px)', 'ginza' ),
				'param_name' => 'items_1500up',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '4', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 1200px - 1499px)', 'ginza' ),
				'param_name' => 'items_1200_1499',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '4', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 992px - 1199px)', 'ginza' ),
				'param_name' => 'items_992_1199',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '4', 'ginza' ),
			), 
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 768px - 991px)', 'ginza' ),
				'param_name' => 'items_768_991',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '3', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 640px - 767px)', 'ginza' ),
				'param_name' => 'items_640_767',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '2', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 480px - 639px)', 'ginza' ),
				'param_name' => 'items_480_639',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '2', 'ginza' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: under 479px)', 'ginza' ),
				'param_name' => 'items_0_479',
				'group'      => __( 'Slider Options', 'ginza' ),
				'value'      => esc_html__( '1', 'ginza' ),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Navigation', 'ginza' ),
				'param_name'  => 'navigation',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'ginza' ),
				'value'       => array(
					__( 'Yes', 'ginza' ) => true,
					__( 'No', 'ginza' )  => false,
				),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Pagination', 'ginza' ),
				'param_name'  => 'pagination',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'ginza' ),
				'value'       => array(
					__( 'No', 'ginza' )  => false,
					__( 'Yes', 'ginza' ) => true,
				),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Item Margin (unit: pixel)', 'ginza' ),
				'param_name'  => 'item_margin',
				'value'       => 30,
				'save_always' => true,
				'group'       => __( 'Slider Options', 'ginza' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Slider speed number (unit: second)', 'ginza' ),
				'param_name'  => 'speed',
				'value'       => '500',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'ginza' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Slider loop', 'ginza' ),
				'param_name'  => 'loop',
				'value'       => true,
				'group'       => __( 'Slider Options', 'ginza' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Slider Auto', 'ginza' ),
				'param_name'  => 'auto',
				'value'       => true,
				'group'       => __( 'Slider Options', 'ginza' ),
			),
			array(
				'type'        => 'dropdown',
				'holder'      => 'div',
				'heading'     => esc_html__( 'Navigation style', 'ginza' ),
				'param_name'  => 'navigation_style',
				'group'       => __( 'Slider Options', 'ginza' ),
				'value'       => array(
					'Navigation center horizontal'	=> 'navigation-style1',
					'Navigation top right'	        => 'navigation-style2',
				),
			),
		);
	}
}